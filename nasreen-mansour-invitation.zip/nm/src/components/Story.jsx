import { useLayoutEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import WeddingScene from './WeddingScene.jsx'
import WelcomeScene from './WelcomeScene.jsx'
import CalendarCountdown from './CalendarCountdown.jsx'
import VenueScene from './VenueScene.jsx'

// مشهد واحد مثبّت: الأسماء ← تكبير الفستان ← ترحيب/آية ← تقويم/عداد ← الفستان ينفلق كستارة ← الصالة
export default function Story({ reduce }) {
  const root = useRef(null)
  const refresh = useRef(() => ScrollTrigger.refresh())

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const q = gsap.utils.selector(root.current)
      const wrap = q('.zoomwrap')[0], stage = q('.stage')[0]
      const S = reduce ? 1 : 2.6
      const toDress = () => ({
        x: stage.clientWidth / 2 - (wrap.offsetLeft + wrap.offsetWidth * 0.33),
        y: stage.clientHeight / 2 - (wrap.offsetTop + wrap.offsetHeight * 0.68),
      })
      const fadeIn = { autoAlpha: 1, y: 0, duration: 1 }, from = { autoAlpha: 0, y: 30 }
      const fadeOut = { autoAlpha: 0, y: -30, duration: 0.8 }

      const tl = gsap.timeline({
        defaults: { ease: 'none' },
        scrollTrigger: { trigger: root.current, start: 'top top', end: () => '+=' + window.innerHeight * 9, pin: true, scrub: 1.2, anticipatePin: 1, invalidateOnRefresh: true },
      })
      tl.to(q('.hero'), { autoAlpha: 0, y: -40, duration: 1.2 }, 0)
        .to(q('.hint'), { autoAlpha: 0, duration: 0.4 }, 0)
        .to(wrap, { scale: S, x: () => (reduce ? 0 : toDress().x), y: () => (reduce ? 0 : toDress().y), duration: 3.2, ease: 'power1.inOut' }, 0.4)
        .to(q('.dim'), { opacity: 1, duration: 1.5 }, 1.8)
        .fromTo(q('.welcome'), from, fadeIn, 2.6).to(q('.welcome'), fadeOut, 4.4)
        .fromTo(q('.verse'), from, fadeIn, 5.0).to(q('.verse'), fadeOut, 6.8)
        .fromTo(q('.cal'), from, fadeIn, 7.3).to(q('.cal'), fadeOut, 9.3)
        // الفستان ينقسم ويصبح ستارة
        .set(q('.couple.main'), { autoAlpha: 0 }, 9.7)
        .set(q('.half'), { autoAlpha: 1 }, 9.7)
        .to(q('.dim'), { opacity: 0.15, duration: 1 }, 9.7)
        .to(q('.half.l'), reduce ? { autoAlpha: 0, duration: 1.5 } : { xPercent: -110, duration: 2.4, ease: 'power2.inOut' }, 9.8)
        .to(q('.half.r'), reduce ? { autoAlpha: 0, duration: 1.5 } : { xPercent: 110, duration: 2.4, ease: 'power2.inOut' }, 9.8)
        .fromTo(q('.venue'), { autoAlpha: 0, scale: 0.94 }, { autoAlpha: 1, scale: 1, duration: 1.4 }, 10.6)
        .to({}, { duration: 1.2 })
    }, root)
    const onLoad = () => ScrollTrigger.refresh()
    window.addEventListener('load', onLoad)
    return () => { window.removeEventListener('load', onLoad); ctx.revert() }
  }, [reduce])

  return (
    <section className="story" ref={root} aria-label="قصتنا">
      <div className="stage">
        <VenueScene />
        <WeddingScene onImageLoad={() => refresh.current()} />
        <div className="dim" aria-hidden="true" />
        <WelcomeScene />
        <CalendarCountdown />
      </div>
    </section>
  )
}
